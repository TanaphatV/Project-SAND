================================
	Project Sandbox 
================================
 Project Sandbox is a 3d falling sand simulation
 
 Controls:
	Move droping point - WASD
	Change camera angle - Arrow keys
	Decrease/Increase sand dropper size - Q/E
	Drop sand - Space bar 

 To run the program, run the ProjectSandBox.exe in Project-Sand folder
 
 For more information on the project visit https://sites.google.com/view/project-sandbox